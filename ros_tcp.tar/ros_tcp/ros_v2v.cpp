#include "include/global_var_defs.hpp"
#include "include/tcp_server.hpp"
#include "include/cv2x.hpp"

//-----------------------主函数---------------------------------
int main(int argc, char *argv[]) 
{
    signal(SIGINT, signalHandler);

    connfd = tcp_server_init();
    std::thread tcp_rx_thread(tcp_recv);

    Cv2xRadio_init();
    Cv2xRadio_create_tx_rx_flow();


    while(1)
    {
        connfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);
        if (0 > connfd) 
        {
            perror("accept error");
            continue;
        }
        std::thread(tcp_recv).detach();
        std::thread(v2v_tx).detach();
        std::thread(v2v_rx).detach();
        std::thread(tcp_send).detach();
        if(exitflag.load())
            break;
    }
    Cv2xRadio_close_tx_rx_flow();
    cout << "Done." << endl;

    return EXIT_SUCCESS;
}



