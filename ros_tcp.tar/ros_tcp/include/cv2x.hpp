#ifndef __CV2X__HPP__
#define __CV2X__HPP__

#include "global_var_defs.hpp"

// Resets the global callback promise   //重置回调函数的 Promise
static inline void resetCallbackPromise(void) 
{     
    gCallbackPromise = promise<ErrorCode>();
}
// Callback function for ICv2xRadioManager->requestCv2xStatus() //C-V2X 状态请求的回调函数
static void cv2xStatusCallback(Cv2xStatus status, ErrorCode error) 
{    
    if (ErrorCode::SUCCESS == error) {
        gCv2xStatus = status;
    }
    gCallbackPromise.set_value(error);
}
// Callback function for ICv2xRadio->createTxSpsFlow()                     //创建 C-V2X Tx SPS flow 的回调函数。
static void createSpsFlowCallback(shared_ptr<ICv2xTxFlow> txSpsFlow,
                                  shared_ptr<ICv2xTxFlow> unusedFlow,
                                  ErrorCode spsError,
                                  ErrorCode unusedError){
    if (ErrorCode::SUCCESS == spsError) {
        gSpsFlow = txSpsFlow;
    }
    gCallbackPromise.set_value(spsError);
}

static void sampleSpsTx(void) 
{     //发送 C-V2X 数据的函数。
    static uint32_t txCount = 0u;
    int sock = gSpsFlow->getSock();   //获取sock
    //cout << "sampleSpsTx(" << sock << ")" << endl;
    struct msghdr message = {0};  //发送消息结构体
    struct iovec iov[1] = {0};    //发送消息结构体
    struct cmsghdr * cmsghp = NULL;
    char control[CMSG_SPACE(sizeof(int))];
    // Send data using sendmsg to provide IPV6_TCLASS per packet
    iov[0].iov_base = txbuf.data();
    iov[0].iov_len = T_BUF_LEN;
    message.msg_iov = iov;
    message.msg_iovlen = 1;
    message.msg_control = control;
    message.msg_controllen = sizeof(control);
    // Fill ancillary data
    int priority = PRIORITY;
    cmsghp = CMSG_FIRSTHDR(&message);
    cmsghp->cmsg_level = IPPROTO_IPV6;
    cmsghp->cmsg_type = IPV6_TCLASS;
    cmsghp->cmsg_len = CMSG_LEN(sizeof(int));
    memcpy(CMSG_DATA(cmsghp), &priority, sizeof(int));
    // Send data
    auto bytes_sent = sendmsg(sock, &message, 0);
    //cout << "bytes_sent=" << bytes_sent << endl;
    if(bytes_sent < 0) {
        cerr << "Error sending message: " << bytes_sent << endl;
        bytes_sent = -1;
    }else{
        if (bytes_sent == T_BUF_LEN) 
        {
           ++txCount;
        } else {
            cerr << "Error : " << bytes_sent << " bytes sent." << endl;
        }
    }
    //cout << "TX count: " << txCount << endl;
}

// Callback for ICv2xRadio->closeTxFlow()  //关闭 C-V2X Tx SPS flow 的回调函数。
static void closeFlowCallback(shared_ptr<ICv2xTxFlow> flow, ErrorCode error) 
{  
    gCallbackPromise.set_value(error);
}

static int sampleRx(void) {

    int sock = gRxSub->getSock();
    char* endPtr = NULL;
    //cout << "sampleRx(" << sock << ")" << endl;
    // 设置接收超时
    struct timeval timeout;
    timeout.tv_sec = 0;
    timeout.tv_usec = 60000; // 5000 微秒 = 5 毫秒
    if (setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout)) < 0) {
        std::cerr << "Error setting socket timeout" << std::endl;
        return -1;
    }
    // Attempt to read from socket
    int n = recv(sock, rxbuf.data(), rxbuf.max_size(), 0);
    if (n < 0) {
        if (errno == EWOULDBLOCK || errno == EAGAIN) {
            std::cerr << "Receive timeout" << std::endl;
            // 处理超时的情况，可以进行相应的操作
        } else {
            std::cerr << "Error occurred reading from socket[" << sock << "]: " << strerror(errno) << std::endl;
        }
    }
    else {
        //cout << __FUNCTION__ << ": Received " << n << " bytes" << endl;
        ++gPacketsReceived;
        //std::cout << "收到缓冲区内的数据" << rxbuf.data() << std::endl;   
        //std::cout <<  gPacketsReceived << std::endl;
    }
    return 0;
}

// Callback function for Cv2xRadio->createRxSubscription() and Cv2xRadio->closeRxSubscription()
static void rxSubCallback(shared_ptr<ICv2xRxSubscription> rxSub, ErrorCode error) 
{
    if (ErrorCode::SUCCESS == error) 
    {
        gRxSub = rxSub;
    }
    gCallbackPromise.set_value(error);
}

int Cv2xRadio_init()
{
    std::vector<std::string> groups{"radio", "system", "gps"};  //设置附加额外的组，获得运行所需权限
    if (-1 == Utils::setSupplementaryGroups(groups)){
        cout << "Adding supplementary group failed!" << std::endl;
    } 
    cout << "Running Sample C-V2X TX app" << endl;
    // Get handle to Cv2xRadioManager
    auto & cv2xFactory = Cv2xFactory::getInstance();
    auto cv2xRadioManager = cv2xFactory.getCv2xRadioManager();  //获取管理句柄 ，指针类型

    // Wait for radio manager to complete initialization 等待初始化
    if (not cv2xRadioManager->isReady()) {
        if (cv2xRadioManager->onReady().get()) {
            cout << "C-V2X Radio Manager is ready" << endl;
        }
        else {
            cerr << "C-V2X Radio Manager initialization failed, exiting" << endl;
            return EXIT_FAILURE;
        }
    }

    // Get C-V2X status and make sure Tx is enabled
    assert(Status::SUCCESS == cv2xRadioManager->requestCv2xStatus(cv2xStatusCallback));  //等待tx的返回结果等待启用
    assert(ErrorCode::SUCCESS == gCallbackPromise.get_future().get());

    if (Cv2xStatusType::ACTIVE == gCv2xStatus.txStatus) {
        cout << "C-V2X TX status is active" << endl;
    }
    else {
        cerr << "C-V2X TX is inactive" << endl;
        return EXIT_FAILURE;
    }
    if (Cv2xStatusType::ACTIVE == gCv2xStatus.rxStatus) {
        cout << "C-V2X RX status is active" << endl;
    }
    else {
        cerr << "C-V2X RX is inactive" << endl;
        return EXIT_FAILURE;
    }

    // Get handle to Cv2xRadio
    cv2xRadio = cv2xRadioManager->getCv2xRadio(TrafficCategory::SAFETY_TYPE);   //得到指针类型的cv2x radio从而发送信息

    // Wait for radio to complete initialization
    if (not cv2xRadio->isReady()) {
        if (Status::SUCCESS == cv2xRadio->onReady().get()) {
            cout << "C-V2X Radio is ready" << endl;
        }
        else {
            cerr << "C-V2X Radio initialization failed." << endl;
            return EXIT_FAILURE;
        }
    } else {
        return EXIT_SUCCESS;
    }
    return 0;
}

void Cv2xRadio_create_tx_rx_flow()
{
    // Create new Tx SPS flow
    // 创建了C-V2X Tx SPS flow，用于发送 C-V2X 数据
    SpsFlowInfo spsInfo;
    spsInfo.priority = Priority::PRIORITY_1;    //指定在SPS流上预留的流量的3GPP优先级之一。默认为PRIORITY_2。
    spsInfo.periodicity = Periodicity::PERIODICITY_10MS; //指定周期
    spsInfo.nbytesReserved = T_BUF_LEN;         //每个周期间隔发送的TX带宽字节数
    spsInfo.autoRetransEnabledValid = true;      //如果指定了autoRetransEnabled字段，则设置为true。如果为false，系统将使用默认设置。
    spsInfo.autoRetransEnabled = true;          //用于启用自动重传。

    resetCallbackPromise();
    assert(Status::SUCCESS == cv2xRadio->createTxSpsFlow(TrafficIpType::TRAFFIC_NON_IP,
                                                         SPS_SERVICE_ID,
                                                         spsInfo,
                                                         SPS_SRC_PORT_NUM,
                                                         false,
                                                         0,
                                                         createSpsFlowCallback));
    assert(Status::SUCCESS == cv2xRadio->createRxSubscription(TrafficIpType::TRAFFIC_NON_IP,
                                                              RX_PORT_NUM,
                                                              rxSubCallback));
    assert(ErrorCode::SUCCESS == gCallbackPromise.get_future().get());
}

void Cv2xRadio_close_tx_rx_flow()
{
    // Deregister SPS flow
    resetCallbackPromise();
    assert(Status::SUCCESS == cv2xRadio->closeTxFlow(gSpsFlow, closeFlowCallback));
    assert(ErrorCode::SUCCESS == gCallbackPromise.get_future().get());
    assert(Status::SUCCESS == cv2xRadio->closeRxSubscription(gRxSub,rxSubCallback));
}


void v2v_tx() 
{
    while (!exitflag.load())
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
        {
            rec_mtx.lock();
            std::memmove(txbuf.data(), tcprx_v2v_flow, 300);
            sampleSpsTx();
            rec_mtx.unlock();
        }
    }
}

void v2v_rx() {
    int previousNumericID = 0;
    while (!exitflag.load()) {
        sampleRx();
        send_mtx.lock();
        std::memmove(v2v_tcptx_flow, rxbuf.data(), 300);
        int* idPtr = reinterpret_cast<int*>(v2v_tcptx_flow);
        uint32_t id = *idPtr;
       // std::cout<<" rx: "<< id<< std::endl;
        read_v2v = 1;
        send_mtx.unlock();
    }
}

#endif
