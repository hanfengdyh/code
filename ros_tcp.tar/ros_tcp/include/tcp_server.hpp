#ifndef __TCP_SERVER_HPP__
#define __TCP_SERVER_HPP__

#include <iostream>
#include <array>
#include <unistd.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <atomic>


#include "global_var_defs.hpp"

#define SERVER_PORT 8111 //端口号不能发生冲突,不常用的端口号通常大于 5000
int sockfd,ret_fd;
struct sockaddr_in client_addr = {0};
socklen_t addrlen = sizeof(client_addr);

int tcp_server_init()
{
    struct sockaddr_in server_addr = {0};
    int ret;
    /* 打开套接字，得到套接字描述符 */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (0 > sockfd) {
        perror("socket error");
        exit(EXIT_FAILURE);
    }
    int sendBufferSize = 1024;
    if (setsockopt(sockfd, SOL_SOCKET, SO_SNDBUF, &sendBufferSize, sizeof(sendBufferSize)) == -1) {
        std::cerr << "Error setting send buffer size." << std::endl;
        close(sockfd);
        return -1;
    }
    //禁用nagle算法
    int nodelay = 1;
    setsockopt(sockfd, IPPROTO_TCP, TCP_NODELAY, (void *)&nodelay , sizeof(nodelay ));
    /* 将套接字与指定端口号进行绑定 */
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(SERVER_PORT);
    ret = bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr));
    if (0 > ret) {
        perror("bind error");
        close(sockfd);
        exit(EXIT_FAILURE);
    }
    /* 使服务器进入监听状态 */
    ret = listen(sockfd, 300);
    if (0 > ret) {
        perror("listen error");
        close(sockfd);
        exit(EXIT_FAILURE);
    }
    return ret_fd;
}

void tcp_recv()
{
    while (!exitflag.load()) {       
        ssize_t ret = recv(connfd, recvbuf, 300, 0);
        if (ret == -1)
        {
            perror("tcp recv failed");
            return;
        }
        rec_mtx.lock();
        std::memmove(tcprx_v2v_flow, recvbuf, 300);
        rec_mtx.unlock();    
    }
}

void tcp_send() {
    static int previousId = -1; 
    while (!exitflag.load()) {
        if (read_v2v == 1) {
            send_mtx.lock();
            uint32_t *idPtr = reinterpret_cast<uint32_t*>(v2v_tcptx_flow);
            uint32_t id = *idPtr;
	    //uint32_t id;
          //  memcpy(&id, v2v_tcptx_flow, sizeof(uint32_t));
			std::cout <<"send:"<< id<< std::endl;
            if (id != previousId&&id != 0 &&id < 1000000) { 
                send(connfd, v2v_tcptx_flow, 240, 0);  //ROS端结构体如果改动，那么这个也要改。
                previousId = id; 
            }
            read_v2v = 0; 
            send_mtx.unlock();
        }
    }
}
#endif /* TCP_SERVER_HPP_ */
