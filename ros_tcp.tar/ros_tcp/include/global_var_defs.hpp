#ifndef __GLOBAL_VAR_DEFS_HPP__
#define __GLOBAL_VAR_DEFS_HPP__

#include <assert.h>
#include <ifaddrs.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <string>
#include <cstring>
#include <iostream>
#include <memory>
#include <chrono>
#include <csignal>
#include <cstdlib>
#include <cstdint>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <thread>
#include <telux/cv2x/Cv2xRadio.hpp>
#include "../../../common/utils/Utils.hpp"
#include <mutex>
#include <fstream>
#include <sstream>
#include <vector>
#include <iterator>
#include <signal.h>
#include <time.h>
#include <netinet/in.h>
#include <condition_variable>
#include <sstream>
#include <iomanip>

using std::array;
using std::cerr;
using std::cout;
using std::endl;
using std::promise;
using std::shared_ptr;
using telux::common::ErrorCode;
using telux::common::Status;
using telux::cv2x::Cv2xFactory;
using telux::cv2x::Cv2xStatus;
using telux::cv2x::Cv2xStatusType;
using telux::cv2x::ICv2xTxFlow;
using telux::cv2x::Periodicity;
using telux::cv2x::Priority;
using telux::cv2x::TrafficCategory;
using telux::cv2x::TrafficIpType;
using telux::cv2x::SpsFlowInfo;
using telux::cv2x::ICv2xRxSubscription;

//# CV2X
std::shared_ptr<telux::cv2x::ICv2xRadio> cv2xRadio;

constexpr uint32_t SPS_SERVICE_ID = 1u;        //sps服务id
constexpr uint16_t SPS_SRC_PORT_NUM = 2500u;   //SPS 流的源端口号
constexpr uint32_t T_BUF_LEN = 250;            //发送缓冲区长度
constexpr int      PRIORITY = 1;               //SPS 流的优先级
constexpr char TEST_VERNO_MAGIC = 'Q';           //测试的魔术号
constexpr char UEID = 1;                          //UE 设备 ID

constexpr uint16_t RX_PORT_NUM = 9000u;
constexpr uint32_t R_BUF_LEN = 250u;           ////接收缓冲区长度
shared_ptr<ICv2xRxSubscription> gRxSub;
uint32_t gPacketsReceived = 0u;

Cv2xStatus gCv2xStatus;  //定义了CV2X的广播的状态 有效值是rxStatus txStatus
promise<ErrorCode> gCallbackPromise;  //用于存储回调函数的 Promise  进行中 失败 已完成
shared_ptr<ICv2xTxFlow> gSpsFlow;    //用于存储 C-V2X Tx SPS flow
array<char, T_BUF_LEN> txbuf;        //用于存储发送的数据
array<char, R_BUF_LEN> rxbuf;        //用于存储接收的数据

std::mutex rec_mtx;
std::mutex send_mtx;
std::atomic<bool> exitflag(false);// 用于通知线程退出的标志
char recvbuf[512];
char tcprx_v2v_flow[1000];
char v2v_tcptx_flow[1000];
int read_v2v = 0;

int connfd = 0;

// Returns current timestamp  //获取当前时间戳
static uint64_t getCurrentTimestamp(void) 
{   
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (uint64_t)tv.tv_sec * 1000000ull + (uint64_t)tv.tv_usec;
}

void signalHandler(int signum)
{
    std::cout << "Interrupt signal (" << signum << ") received.\n"; 
    exitflag.store(true);
}

#endif